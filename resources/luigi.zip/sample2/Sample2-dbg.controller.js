sap.ui.define(
  ['sap/ui/core/mvc/Controller', 'luigi/demo/libs/luigi-client/luigi-client'],
  (Controller) => {
    'use strict';

    return Controller.extend('luigi.demo.sample2.Sample2', {});
  }
);
