sap.ui.define(
  ['sap/ui/core/mvc/Controller', 'luigi/demo/libs/luigi-client/luigi-client'],
  (Controller) => {
    'use strict';

    return Controller.extend('luigi.demo.sample1.Sample1', {});
  }
);
